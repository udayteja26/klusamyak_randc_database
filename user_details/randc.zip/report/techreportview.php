<?php session_start();
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}

// including the database connection file
include_once("connection.php");

//getting id from url
$sno = $_GET['sno'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM samyak_details WHERE sno=$sno");

while($res = mysqli_fetch_array($result))
{
	$samyak_id = $res['samyak_id'];
	$name = $res['name'];
	
	$events = $res['tech_events'];
	}
?>
<html>
<head>	
<meta charset="UTF-8">
  <title>Samyak User Data Form</title>
  
         <link rel="stylesheet" href="css/style.css">
	<title>Edit Data</title>
</head>

<body>
 <h2 align="right" >		
		   Welcome: <?php echo $_SESSION['name'] ?> </br>
		    <a href="index.php">Home</a>
		   <a href="logout.php">Logout</a>
          	   
		 </h2> 

	<form name="form1" method="post" action="techreporttech.php">
		<table border="0">
			
		
		
		 <fieldset>
          <legend><span class="number">1</span>Tech Report Form</legend>

		  <label for="samyak_id">Samyak ID:</label>
             <input type="text" id="samyak_id" name="samyak_id" readonly value="<?php echo $samyak_id; ?>"  required />
		  
		<label for="name">Name:</label>
          <input type="text"  name="name" readonly value="<?php echo $name;?>" required />
          
          <label for="events">Tech Events Status:</label>
             <input type="text" id="events" name="events" readonly value="<?php echo $events;?>"  required />
              		   
              		   
         
     	</fieldset>
				 
		 

		 <button type="submit" name="insert">Attended</button>
		</table>
	</form>
</body>
</html>
