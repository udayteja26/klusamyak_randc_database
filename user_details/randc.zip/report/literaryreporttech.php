<?php session_start();
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}

  
  $con =mysqli_connect('127.0.0.1','root','');
  
   if(!$con)
   {
	   echo 'not connected to server';
   }
   
   if(!mysqli_select_db($con,'uday'))
   {
	   echo 'database not selected';
   }
   
    
    
	$samyak_id = $_POST['samyak_id'];
	 $events = $_POST['events'];

   if($events=='cert_written')
		{
			echo 'Certificate written';
		}
        else
		{
    	 	


//$sql ="INSERT INTO samyak_details (samyak_id,name,email,mobile,user_city,blood_group,college_name,college_id,stream,branch,college_city,events,login_id) VALUES ('$samyak_id','$name','$email','$mobile','$user_city','$blood_group','$college_name','$college_id','$stream','$branch','$college_city','$b','$loginId')";
     
//	$sql = "UPDATE samyak_details SET name='$name',samyak_id='$samyak_id',email='$email',mobile='$mobile',user_city='$user_city',blood_group='$blood_group',college_name='$college_name',college_id='$college_id',stream='$stream',branch='$branch',college_city='$college_city',events='$events',lastmodified_id='$lastmodified_id' WHERE samyak_id=samyak_id ";
    $sql = "UPDATE `samyak_details` SET `literary`='".'literary_attended'."' WHERE `samyak_id` = '$samyak_id'";	
	if(!mysqli_query($con,$sql))
	 {
		 echo 'not updated';
	 }
	 
	 else
	 {
		 echo "<script>window.close();</script>";
	 }

   
	}
 
?>