<?php session_start();
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
 $con =mysqli_connect('127.0.0.1','root','');
  
   if(!$con)
   {
	   echo 'not connected to server';
   }
   
   if(!mysqli_select_db($con,'uday'))
   {
	   echo 'database not selected';
   }
   
    
    
	$samyak_id = $_POST['samyak_id'];
  $sql = "UPDATE `samyak_details` SET `project`='".'cert_written'."' WHERE `samyak_id` = '$samyak_id'";	
	if(!mysqli_query($con,$sql))
	 {
		 echo 'not updated';
	 }
	 
	 else
	 {
		 echo "<script>window.close();</script>";
	 }   
 
?>