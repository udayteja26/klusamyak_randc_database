<?php session_start();
  if(isset($_SESSION['valid'])) {			
include("connection.php");					
	     $result = mysqli_query($mysqli, "SELECT * FROM login");
	           ?>
<html>
<link rel="stylesheet" type="text/css" href="css1.css">
   <head> 
       <title>Certificate Pages</title>
   </head>
  <body> 
    <div id="border">
      <header id="topheader">
            <h1 align="center">Certificate Pages </h1>
			   
	    <h2 align="right" >		
		   Welcome: <?php echo $_SESSION['name'] ?> </br>
		 </h2> 
        </header>  
        <div id="formborder">
	    <h1 align="center"></h1>
               <div class="container" >
       			<button type="button" class="cancelbtn"><a target='_blank' href="techcertindex.php">Tech</a></button>
				<button type="button" class="cancelbtn"><a target='_blank' href="nontechcertindex.php">Non Tech</a></button>
				<button type="button" class="cancelbtn"><a target='_blank' href="projectcertindex.php">Project</a></button>
				<button type="button" class="cancelbtn"><a target='_blank' href="papercertindex.php">Paper</a></button>
				<button type="button" class="cancelbtn"><a target='_blank' href="postercertindex.php">Poster</a></button>
				<button type="button" class="cancelbtn"><a target='_blank' href="literarycertindex.php">Literary</a></button>
			    <button type="button" class="cancelbtn"><a  href="logout.php">LogOut</a></button>
       </div>
	<?php	
	} else 
	{
		echo "You must be logged in to view this page.";
		header('Location:login.php');
	}
	?> 
  </div>
</div>	
  </body>  
</html>