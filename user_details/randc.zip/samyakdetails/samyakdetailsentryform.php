<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php
// including the database connection file
include_once("connection.php");


?>
<?php
//getting id from url
$sno = $_GET['sno'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM user_details WHERE sno=$sno");

while($res = mysqli_fetch_array($result))
{
	$name = $res['name'];
	$email = $res['email'];
	$mobile = $res['mobile'];
	$user_city=$res['user_city'];
	$blood_group=$res['blood_group'];
	$college_name=$res['college_name'];
	$college_id=$res['college_id'];
	$stream=$res['stream'];
	$branch=$res['branch'];
	$college_city=$res['college_city'];
	}
?>
<html>
<head>	
<meta charset="UTF-8">
  <title>Samyak User Data Form</title>
  
         <link rel="stylesheet" href="css/style.css">
	<title>Edit Data</title>
</head>

<body>
	
	<h2 align="right" >		
		   Welcome: <?php echo $_SESSION['name'] ?> </br>
		   <a href="logout.php">Logout</a>
	</h2>
	<br/><br/>
	
	<form name="form1" method="post" action="samyakdetailsentryformconn.php">
		<table border="0">
			
		
		
		 <fieldset>
          <legend><span class="number">1</span>Your Personal Information</legend>
          <label for="name">Name:</label>
          <input type="text"  name="name" value="<?php echo $name;?>" required />
          
          <label for="mail">Email:</label>
          <input type="text"  name="email" value="<?php echo $email;?>" required />
		  
		   <label for="mobile">mobile:</label>
           <input type="number"  name="mobile" value="<?php echo $mobile;?>" required />
		   
		   
		   <label for="user_city">City:</label>
           <input type="user_city"  name="user_city" value="<?php echo $user_city;?> "required/>

		   <label for="blood_group">blood_group:</label>
           <input type="text"  name="blood_group" value="<?php echo $blood_group;?> "required/>
              		   
              		   
         
     	</fieldset>
		<fieldset>
          <legend><span class="number">2</span>Your College Information</legend>
         
           <label for="college_name">College name:</label>
           <input type="text"  name="college_name" value="<?php echo $college_name;?>" required />
		  
		    <label for="college_id">college id:</label>
            <input type="number" name="college_id" value="<?php echo $college_id;?>" required />
		  
		     <label for="stream">Stream:</label>
             <input type="stream" id="stream" name="stream" value="<?php echo $stream;?>" required /> 
		   
		     <label for="branch">Branch:</label>
             <input type="branch" id="branch" name="branch" value="<?php echo $branch;?>" required />
		   
		     <label for="city">City:</label>
             <input type="college_city" id="college_city" name="college_city" value="<?php echo $mobile;?>" required />
             </select>

         </fieldset>
	  
	  <fieldset>
	 <label for="samyak_id">Samyak ID:</label>
             <input type="text" id="samyak_id" name="samyak_id"  required />
         <fieldset>
 
	   <fieldset>
          <legend><span class="number">3</span>Samyak Information</legend>
         
          
    
          <input type="checkbox"   name="events[]" value="tech events" > <label class="light" for="tech">Tech Events</label>
          <input type="checkbox"   name="events[]" value="non tech events" > <label class="light" for="nontech">Non-Tech Events </label><br>
          <input type="checkbox"   name="events[]" value="workshops "> <label class="light" for="workshops">Workshops</label><br>
          <input type="checkbox"   name="events[]" value="literary events"> <label class="light" for="literary">Literary Events</label><br>
          <input type="checkbox"   name="events[]" value="paper "> <label class="light" for="paper">Paper presentation</label>
		  <input type="checkbox"   name="events[]" value="poster"> <label class="light" for="poster">Poster Presentation</label><br>
          <input type="checkbox"   name="events[]" value="project"> <label class="light" for="project">Project Expo</label><br>
		  <input type="checkbox"   name="events[]" value="proshow"> <label class="light" for="proshow">Pro Show</label><br>
    
          
     

         </fieldset>
		 
		 

		 <button type="submit" name="insert">Save</button>
		</table>
	</form>
</body>
</html>
