<?php session_start(); ?>
<html>
<link rel="stylesheet" type="text/css" href="css1.css">
   <head> 
         <title>User Detials Index</title>
   </head>

  <body> 
  
    <div id="border">
      <header id="topheader">
            <h1 align="center">User Detials Index </h1>
			 
			   <?php
	               if(isset($_SESSION['valid'])) {			
		              include("connection.php");					
	                	$result = mysqli_query($mysqli, "SELECT * FROM login");
	           ?>
			   
		 <h2 align="right" >		
		   Welcome: <?php echo $_SESSION['name'] ?> </br>
		   
          	   
		 </h2> 
        </header>  
       
	
		 
		

     <div id="formborder">
	 
        <h1 align="center"></h1>
               <div class="container" >
                   
				  
				    <button type="button" class="cancelbtn"><a target='_blank' href="view.php">View Data</a></button>
					 <button type="button" class="cancelbtn"><a target='_blank' href="entryview.php">Entry View Data</a></button>
					<button type="button" class="cancelbtn"><a  href="logout.php">LogOut</a></button>
    
                    </div>
				
				
					
     
	   
	 <?php	
	} else 
	{
		echo "You must be logged in to view this page.";
		
		header('Location: login.php');
	}
	?> 
  </div>
</div>	
  
 </body>  


</html>




