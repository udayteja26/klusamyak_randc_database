<?php session_start();
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
include_once("connection.php");
$sno = $_GET['sno'];

$result = mysqli_query($mysqli, "SELECT * FROM user_details WHERE sno=$sno");

while($res = mysqli_fetch_array($result))
{
	$name = $res['name'];
	$email = $res['email'];
	$mobile = $res['mobile'];
	$user_city=$res['user_city'];
	$blood_group=$res['blood_group'];
	$college_name=$res['college_name'];
	$college_id=$res['college_id'];
	$stream=$res['stream'];
	$degree=$res['degree'];
	$college_city=$res['college_city'];
	}
?>
<html>
<head>	
<meta charset="UTF-8">
  <title>Samyak User Data Form</title>
  
         <link rel="stylesheet" href="css/style.css">
	<title>Edit Data</title>
</head>

<body>
	
	<h2 align="right" >		
		   Welcome: <?php echo $_SESSION['name'] ?> </br>
		   <a href="logout.php">Logout</a>
	</h2>
	<br/><br/>
	
	<form name="form1" method="post" action="samyakdetailsentryformconn.php">
		<table border="0">
			
		
		
		 <fieldset>
          <legend><span class="number">1</span>Your Personal Information</legend>
          <label for="name">Name:</label>
          <input type="text"  name="name" value="<?php echo $name;?>" required />
          
          <label for="mail">Email:</label>
          <input type="text"  name="email" value="<?php echo $email;?>" required />
		  
		   <label for="mobile">mobile:</label>
           <input type="number"  name="mobile" value="<?php echo $mobile;?>" required />
		   
		   
		   <label for="user_city">City:</label>
           <input type="user_city"  name="user_city" value="<?php echo $user_city;?> "required/>

		   <label for="blood_group">blood_group:</label>
           <input type="text"  name="blood_group" value="<?php echo $blood_group;?> "required/>
              		   
              		   
         
     	</fieldset>
		<fieldset>
          <legend><span class="number">2</span>Your College Information</legend>
         
           <label for="college_name">College name:</label>
           <input type="text"  name="college_name" value="<?php echo $college_name;?>" required />
		  
		    <label for="college_id">college id:</label>
            <input type="number" name="college_id" value="<?php echo $college_id;?>" required />
		  
		   <label for="branch">Degree:</label>
             <input type="branch" id="branch" name="degree" value="<?php echo $degree;?>" required />
			 
		     <label for="stream">Stream:</label>
             <input type="stream" id="stream" name="stream" value="<?php echo $stream;?>" required /> 
		   
		    
		   
		     <label for="city">City:</label>
             <input type="college_city" id="college_city" name="college_city" value="<?php echo $mobile;?>" required />
             </select>

  </fieldset>
                <fieldset>
          <legend><span class="number">3</span>Samyak Information</legend>
         
          <legend>  <label for="tech">Workshop</label></legend>
        <fieldset> <input type="radio" name="workshops" value="workshops" >Registered
                  <input type="radio" name="workshops" value="N_I" checked>Not Registered </fieldset>
		  
         <legend>  <label for="tech">Tech Events</label></legend>
        <fieldset> <input type="radio" name="tech" value="tech" >Registered
                   <input type="radio" name="tech" value="N_I" checked>Not Registered </fieldset>
		 
		 <legend>  <label for="tech">Paper Presentation</label></legend>
          <fieldset><input type="radio" name="paper" value="paper" >Registered 
                   <input type="radio" name="paper" value="N_I" checked>Not Registered </fieldset>
		 
		 <legend>  <label for="tech">Poster Presentation</label></legend>
        <fieldset> <input type="radio" name="poster" value="poster" >Registered
                  <input type="radio" name="poster" value="N_I" checked>Not Registered </fieldset>
		 
		 <legend>  <label for="tech">Literary Events</label></legend>
          <fieldset><input type="radio" name="literary" value="literary" >Registered 
                 <input type="radio" name="literary" value="N_I" checked>Not Registered </fieldset>
            
			<legend>  <label for="tech">Project Expo</label></legend>
        <fieldset> <input type="radio" name="project" value="project" >Registered
                   <input type="radio" name="project" value="N_I" checked>Not Registered </fieldset>
		 
		 
		 
		  <legend>  <label for="tech">Culturals</label></legend>
          <fieldset><input type="radio" name="culturals" value="culturals" >Registered 
         <input type="radio" name="culturals" value="N_I" checked>Not Registered </fieldset>
		 
		  <legend>  <label for="tech">Ambassador</label></legend>
          <fieldset><input type="radio" name="ambassador" value="ambassador" >Registered 
         <input type="radio" name="ambassador" value="N_I" checked>Not Registered </fieldset>
    
	
	
          
     

         </fieldset>
		 <fieldset>
             
		     <label for="samyak_id">Samyak Id:</label>
             <input type="text" id="samyak_id" name="samyak_id" required />		 
            <fieldset>
        <button type="submit" name="insert">Save</button>
      </form>
      
    </body>
</html>
  
  
</body>
</html>