<?php session_start();
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
include("connection.php");
  $con =mysqli_connect('localhost','root','');
  
   if(!$con)
   {
	   echo 'not connected to server';
   }
   
   if(!mysqli_select_db($con,'samyak'))
   {
	   echo 'database not selected';
   }
   
   $name = $_POST['name'];
	$email = $_POST['email'];
	$mobile=$_POST['mobile'];
	$user_city=$_POST['user_city'];
	$blood_group=$_POST['blood_group'];
	$college_name=$_POST['college_name'];
	$college_id=$_POST['college_id'];
	$stream=$_POST['stream'];
	$degree=$_POST['degree'];
	$college_city=$_POST['college_city'];
	$workshops=$_POST['workshops'];
	$tech=$_POST['tech'];
	$paper=$_POST['paper'];
    $poster=$_POST['poster'];
	$literary=$_POST['literary'];
	$project=$_POST['project'];
	$culturals=$_POST['culturals'];
	$ambassador=$_POST['ambassador'];
	$samyak_id=$_POST['samyak_id'];
	
	$result = mysqli_query($mysqli, "SELECT * FROM samyak_details ");

     while($res = mysqli_fetch_array($result))
       {
	     $samyakid = $res['samyak_id'];
	
	
	   }
	    $sam=$samyakid;

    	if($samyak_id==$sam)
		{
			echo 'Please provide valid samyakid';
		}
        else
		{
             $sql ="INSERT INTO samyak_details (name,email,mobile,user_city,blood_group,college_name,college_id,stream,degree,college_city,tech,workshops,paper,poster,literary,project,culturals,ambassador,samyak_id) VALUES ('$name','$email','$mobile','$user_city','$blood_group','$college_name','$college_id','$stream','$degree','$college_city','$tech','$workshops','$paper','$poster','$literary','$project','$culturals','$ambassador','$samyak_id')";
     
	         if(!mysqli_query($con,$sql))
	          {
	           	 echo 'not inserted';
	          }
	 
	         else
	          {
		            header('Location:index.php');
	          }

		 }
   
	   
?>