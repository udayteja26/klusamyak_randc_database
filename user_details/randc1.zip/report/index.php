<?php session_start();
  if(isset($_SESSION['valid'])) {			
include("connection.php");					
$result = mysqli_query($mysqli, "SELECT * FROM login");
	           ?>
<html>
<link rel="stylesheet" type="text/css" href="css1.css">
   <head> 
       <title>User Detials Index</title>
   </head>
  <body> 
    <div id="border">
      <header id="topheader">
            <h1 align="center">Report Pages </h1>
			   
	    <h2 align="right" >		
		   Welcome: <?php echo $_SESSION['name'] ?> </br>
		 </h2> 
        </header>  
        <div id="formborder">
	    <h1 align="center"></h1>
               <div class="container" >
       			<button type="button" class="cancelbtn"><a target='_blank' href="techreportindex.php">Tech</a></button>
				
				<button type="button" class="cancelbtn"><a target='_blank' href="projectreportindex.php">Project</a></button>
				<button type="button" class="cancelbtn"><a target='_blank' href="paperreportindex.php">Paper</a></button>
				<button type="button" class="cancelbtn"><a target='_blank' href="posterreportindex.php">Poster</a></button>
				<button type="button" class="cancelbtn"><a target='_blank' href="literaryreportindex.php">Literary</a></button>
			    <button type="button" class="cancelbtn"><a  href="logout.php">LogOut</a></button>
       </div>
	<?php	
	} else 
	{
		echo "You must be logged in to view this page.";
		header('Location:login.php');
	}
	?> 
  </div>
</div>	
  </body>  
</html>